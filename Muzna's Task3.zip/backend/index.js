// backend/index.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use('/api/products', require('./routes/products'));

// backend/index.js
const mongoose = require('mongoose');

const mongoURI = 'mongodb://localhost:27017/ecommerce'; // Replace with your MongoDB connection string

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Define a sample schema and model
const ProductSchema = new mongoose.Schema({
  name: String,
  price: Number,
  description: String,
  category: String,
  image: String,
  date: { type: Date, default: Date.now }
});

const Product = mongoose.model('Product', ProductSchema);

// Insert a sample product
const sampleProduct = new Product({
  name: 'Sample Product',
  price: 10.99,
  description: 'This is a sample product.',
  category: 'Sample Category',
  image: 'sample-image-url'
});

sampleProduct.save()
  .then(() => console.log('Sample product saved'))
  .catch(err => console.log(err));


mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Routes
app.get('/', (req, res) => res.send('API Running'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
